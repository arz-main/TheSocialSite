export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: string;
}

export interface Drawing {
  id: string;
  userId: string;
  username: string;
  imageUrl: string;
  referenceUrl?: string;
  category: string;
  duration: number;
  createdAt: string;
  likes: number;
  showWithReference: boolean;
}

export const badges: Badge[] = [
  {
    id: "1",
    name: "First Steps",
    description: "Complete your first drawing session",
    icon: "🎨",
    earned: true,
    earnedDate: "2026-01-15",
  },
  {
    id: "2",
    name: "Dedicated Artist",
    description: "Maintain a 7-day streak",
    icon: "🔥",
    earned: true,
    earnedDate: "2026-01-22",
  },
  {
    id: "3",
    name: "Speed Sketcher",
    description: "Complete 50 quick sketches (under 2 minutes)",
    icon: "⚡",
    earned: true,
    earnedDate: "2026-02-01",
  },
  {
    id: "4",
    name: "Master of Hands",
    description: "Complete 100 hand studies",
    icon: "✋",
    earned: false,
  },
  {
    id: "5",
    name: "Century Club",
    description: "Complete 100 drawing sessions",
    icon: "💯",
    earned: true,
    earnedDate: "2026-02-05",
  },
  {
    id: "6",
    name: "Marathon Artist",
    description: "Draw for 3 hours in a single day",
    icon: "🏃",
    earned: false,
  },
];

export const currentUserDrawings: Drawing[] = [
  {
    id: "1",
    userId: "current",
    username: "You",
    imageUrl: "figure-sketch-practice",
    referenceUrl: "figure-reference-pose",
    category: "Figure Drawing",
    duration: 300,
    createdAt: "2026-02-09T10:30:00",
    likes: 24,
    showWithReference: true,
  },
  {
    id: "2",
    userId: "current",
    username: "You",
    imageUrl: "hand-study-sketch",
    category: "Hands",
    duration: 120,
    createdAt: "2026-02-09T09:15:00",
    likes: 18,
    showWithReference: false,
  },
  {
    id: "3",
    userId: "current",
    username: "You",
    imageUrl: "still-life-drawing",
    referenceUrl: "still-life-objects",
    category: "Still Life",
    duration: 600,
    createdAt: "2026-02-08T14:20:00",
    likes: 31,
    showWithReference: true,
  },
];
export const userDrawingImages: Record<string, string> = {
  "1": "https://images.unsplash.com/photo-1725299249146-ee7e76af658d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza2V0Y2glMjBkcmF3aW5nJTIwYXJ0fGVufDF8fHx8MTc3MDY2MTkzOHww&ixlib=rb-4.1.0&q=80&w=1080",
  "2": "https://images.unsplash.com/photo-1684175890099-f0507537103a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZW5jaWwlMjBkcmF3aW5nJTIwYXJ0d29ya3xlbnwxfHx8fDE3NzA2NjE5Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080",
  "3": "https://images.unsplash.com/photo-1765029582782-8b53b4ae41bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGFyY29hbCUyMHNrZXRjaCUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDU3ODgzNXww&ixlib=rb-4.1.0&q=80&w=1080",
};