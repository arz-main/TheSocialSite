export const userDrawingImages: Record<string, string> = {
  "1": "https://images.unsplash.com/photo-1725299249146-ee7e76af658d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza2V0Y2glMjBkcmF3aW5nJTIwYXJ0fGVufDF8fHx8MTc3MDY2MTkzOHww&ixlib=rb-4.1.0&q=80&w=1080",
  "2": "https://images.unsplash.com/photo-1684175890099-f0507537103a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZW5jaWwlMjBkcmF3aW5nJTIwYXJ0d29ya3xlbnwxfHx8fDE3NzA2NjE5Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080",
  "3": "https://images.unsplash.com/photo-1765029582782-8b53b4ae41bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGFyY29hbCUyMHNrZXRjaCUyMHBvcnRyYWl0fGVufDF8fHx8MTc3MDU3ODgzNXww&ixlib=rb-4.1.0&q=80&w=1080",
};