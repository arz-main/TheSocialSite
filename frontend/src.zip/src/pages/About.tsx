const About = () => {
	return (
		<div className="w-full mx-screen p-6">
			<h1 className="text-text text-3xl font-bold">About Us</h1>
			<p className="text-text mb-4">
				This is the About page. For now it's empty #Denis
			</p>
			<div className="min-h-screen bg-gray-100 flex items-center justify-center text-gray-400">
				Wow more content
			</div>
		</div>
	);
};

export default About;
