export default function Admin() {
	return <div className="p-6 text-xl">Admin Panel</div>;
}